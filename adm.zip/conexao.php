<?php

	
 $conm = new PDO("mysql:host=br892.hostgator.com.br;dbname=pontadof_gaper_l",'pontadof_felipe','Fsc@1320');

?>