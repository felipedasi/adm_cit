<meta http-equiv="refresh" content="10;URL=index.html">

<?php
require 'conexao.php';
$item = $_POST['item'];
$nome =  $_POST['nome'];
echo $item;
echo $aluno;



//insere no banco

$qtd= $conm->exec("INSERT INTO itens (id, item, aluno) VALUES (NULL,'$item','$nome')");


 
?>
<script>
alert("Item cadastrado com sucesso!")

</script>